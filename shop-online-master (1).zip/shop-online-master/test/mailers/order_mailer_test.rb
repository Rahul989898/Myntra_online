require "test_helper"

class OrderMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
