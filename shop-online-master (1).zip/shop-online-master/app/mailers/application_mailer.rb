class ApplicationMailer < ActionMailer::Base
  default from: "itsabhigupta222@gmail.com"
  layout "mailer"
end
